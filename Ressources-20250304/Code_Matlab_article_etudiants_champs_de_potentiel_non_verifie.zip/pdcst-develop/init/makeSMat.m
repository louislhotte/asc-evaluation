function sMat = makeSMat(trackers,targets,objectives,neutrals)
sMat=[trackers;targets;objectives;neutrals];
end

