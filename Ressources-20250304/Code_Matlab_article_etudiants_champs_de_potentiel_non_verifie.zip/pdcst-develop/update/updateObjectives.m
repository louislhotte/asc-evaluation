function newObjectives = updateObjectives(objectives)
%updateObjectives returns the new positions of objectives
newObjectives=objectives;
end

