function s = score(m,p)
%score returns the score of a simulation from its measurements and
%parameters (targets' score, opposite of the trackers' score)
s=m.deliveries;
end

